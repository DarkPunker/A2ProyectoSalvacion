module.exports = {

    database:{
        multipleStatements: true,
        connectionLimint: 5,
        host: 'bwrsrezgu3vrljz8hdvo-mysql.services.clever-cloud.com',
        user: 'unrkod59ajbpajtv',
        password: '4RipFx6YfV9XsJQxzRRC',
        database: 'bwrsrezgu3vrljz8hdvo'

    }

};